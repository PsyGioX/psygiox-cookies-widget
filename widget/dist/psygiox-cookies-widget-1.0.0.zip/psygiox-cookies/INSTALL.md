# PGX Cookies Widget v1.0.0 — install

<!-- Copyright (C) 2026 PsyGioX <https://github.com/PsyGioX> · SPDX-License-Identifier: GPL-3.0-only -->

1. Copy this folder to your site, e.g. /assets/psygiox-cookies/.
2. Add this as the FIRST script in <head> (it must run before analytics/ads):

   <script src="/assets/psygiox-cookies/psygiox-cookies.min.js"
           data-policy="/cookies" data-privacy="/privacy"></script>

   Everything in one file (no extra requests, ready for strict SRI): psygiox-cookies.bundle.min.js
3. Verify the files:  sha256sum -c SHA256SUMS
4. Docs: https://github.com/PsyGioX/psygiox-cookies-widget/blob/main/docs/API.md
Licensed under GPL-3.0-only — see LICENSE.
